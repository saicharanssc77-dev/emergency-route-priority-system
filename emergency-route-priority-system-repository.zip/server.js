require('dotenv').config();
const path = require('path');
const http = require('http');
const express = require('express');
const session = require('express-session');
const MySQLStoreFactory = null;
const bcrypt = require('bcryptjs');
const mysql = require('mysql2/promise');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = Number(process.env.PORT || 3000);
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'emergency_route_priority',
  waitForConnections: true,
  connectionLimit: 10
});

app.use(express.json({ limit: '100kb' }));
app.use(express.urlencoded({ extended: false }));
app.use(session({
  name: 'ers.sid',
  secret: process.env.SESSION_SECRET || 'development-only-change-this-secret',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 8 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname, 'public')));

const emergencyTypes = [
  'Ambulance and Medical', 'Fire and Rescue', 'Police', 'Disaster Response',
  'Organ and Blood Transport', 'Electricity Emergency', 'Water and Utility Emergency', 'Animal Rescue'
];
const statuses = ['New', 'Acknowledged', 'Responding', 'Resolved'];
const safeUser = u => ({ id: u.id, name: u.name, username: u.username, role: u.role });
function requireAuth(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: 'Please log in first.' });
  next();
}
function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.session.user) return res.status(401).json({ error: 'Please log in first.' });
    if (!roles.includes(req.session.user.role)) return res.status(403).json({ error: 'You do not have permission for this action.' });
    next();
  };
}
async function getAlerts() {
  const [rows] = await pool.query(`SELECT a.id, a.emergency_type, a.destination, a.latitude, a.longitude,
    a.message, a.status, a.created_at, a.updated_at, u.name AS driver_name,
    p.name AS police_name FROM alerts a JOIN users u ON a.created_by=u.id
    LEFT JOIN users p ON a.assigned_to=p.id ORDER BY a.created_at DESC LIMIT 200`);
  return rows;
}

app.get('/api/health', async (_req, res) => {
  try { await pool.query('SELECT 1'); res.json({ ok: true, database: 'connected' }); }
  catch (_e) { res.status(503).json({ ok: false, database: 'unavailable', hint: 'Check MySQL and your .env settings.' }); }
});

app.post('/api/login', async (req, res) => {
  try {
    const username = String(req.body.username || '').trim();
    const password = String(req.body.password || '');
    if (!username || !password) return res.status(400).json({ error: 'Enter username and password.' });
    const [rows] = await pool.execute('SELECT * FROM users WHERE username=? LIMIT 1', [username]);
    if (!rows.length || !(await bcrypt.compare(password, rows[0].password_hash))) {
      return res.status(401).json({ error: 'Incorrect username or password.' });
    }
    req.session.user = safeUser(rows[0]);
    res.json({ user: req.session.user });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Login failed. Check the database setup.' }); }
});
app.post('/api/logout', (req, res) => req.session.destroy(() => { res.clearCookie('ers.sid'); res.json({ ok: true }); }));
app.get('/api/me', (req, res) => res.json({ user: req.session.user || null }));

app.get('/api/alerts', requireAuth, async (_req, res) => {
  try { res.json({ alerts: await getAlerts() }); }
  catch (e) { console.error(e); res.status(500).json({ error: 'Could not load alerts.' }); }
});

app.post('/api/alerts', requireRole('driver', 'admin'), async (req, res) => {
  try {
    const type = String(req.body.emergencyType || '');
    const destination = String(req.body.destination || '').trim().slice(0, 255);
    const message = String(req.body.message || '').trim().slice(0, 500);
    const lat = Number(req.body.latitude), lng = Number(req.body.longitude);
    if (!emergencyTypes.includes(type)) return res.status(400).json({ error: 'Select a valid emergency type.' });
    if (!destination) return res.status(400).json({ error: 'Enter a destination.' });
    if (!Number.isFinite(lat) || lat < -90 || lat > 90 || !Number.isFinite(lng) || lng < -180 || lng > 180) {
      return res.status(400).json({ error: 'Select a valid destination on the map.' });
    }
    const [result] = await pool.execute('INSERT INTO alerts (created_by, emergency_type, destination, latitude, longitude, message) VALUES (?, ?, ?, ?, ?, ?)', [req.session.user.id, type, destination, lat, lng, message]);
    const [rows] = await pool.execute('SELECT a.id, a.emergency_type, a.destination, a.latitude, a.longitude, a.message, a.status, a.created_at, a.updated_at, u.name AS driver_name, NULL AS police_name FROM alerts a JOIN users u ON a.created_by=u.id WHERE a.id=?', [result.insertId]);
    io.emit('alerts:changed', { reason: 'created' });
    res.status(201).json({ alert: rows[0] });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Could not create alert.' }); }
});

app.patch('/api/alerts/:id/status', requireRole('police', 'admin'), async (req, res) => {
  try {
    const id = Number(req.params.id);
    const status = String(req.body.status || '');
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: 'Invalid alert ID.' });
    if (!statuses.includes(status)) return res.status(400).json({ error: 'Invalid status.' });
    const assignedTo = status === 'Resolved' ? req.session.user.id : req.session.user.id;
    const [result] = await pool.execute('UPDATE alerts SET status=?, assigned_to=? WHERE id=?', [status, assignedTo, id]);
    if (!result.affectedRows) return res.status(404).json({ error: 'Alert not found.' });
    io.emit('alerts:changed', { reason: 'updated', id });
    res.json({ ok: true });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Could not update alert.' }); }
});

app.get('/api/admin/summary', requireRole('admin'), async (_req, res) => {
  try {
    const [[{ total }]] = await pool.query('SELECT COUNT(*) AS total FROM alerts');
    const [byStatus] = await pool.query('SELECT status, COUNT(*) AS count FROM alerts GROUP BY status');
    const [byType] = await pool.query('SELECT emergency_type AS type, COUNT(*) AS count FROM alerts GROUP BY emergency_type ORDER BY count DESC');
    const [users] = await pool.query('SELECT id, name, username, role, created_at FROM users ORDER BY role, name');
    res.json({ total, byStatus, byType, users });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Could not load admin summary.' }); }
});

io.on('connection', socket => {
  socket.emit('system:connected', { ok: true });
});

app.get('/api/routes/traffic', requireAuth, async (req, res) => {
  try {
    const originLat = Number(req.query.originLat);
    const originLng = Number(req.query.originLng);
    const destLat = Number(req.query.destLat);
    const destLng = Number(req.query.destLng);

    const validCoordinate = (lat, lng) =>
      Number.isFinite(lat) &&
      Number.isFinite(lng) &&
      lat >= -90 && lat <= 90 &&
      lng >= -180 && lng <= 180;

    if (
      !validCoordinate(originLat, originLng) ||
      !validCoordinate(destLat, destLng)
    ) {
      return res.status(400).json({
        error: 'Valid origin and destination coordinates are required.'
      });
    }

    const apiKey = process.env.TOMTOM_API_KEY;

    if (!apiKey) {
      return res.status(500).json({
        error: 'TomTom API key is missing from server configuration.'
      });
    }

    const locations =
      `${originLat},${originLng}:${destLat},${destLng}`;

    const url = new URL(
      `https://api.tomtom.com/routing/1/calculateRoute/${locations}/json`
    );

    url.searchParams.set('key', apiKey);
    url.searchParams.set('traffic', 'true');
    url.searchParams.set('routeType', 'fastest');
    url.searchParams.set('maxAlternatives', '3');
    url.searchParams.set('sectionType', 'traffic');
    url.searchParams.set('computeTravelTimeFor', 'all');

    const response = await fetch(url);
    const data = await response.json();

    if (!response.ok) {
      console.error('TomTom routing request failed:', response.status);
      return res.status(502).json({
        error: 'Traffic routing service failed.',
        providerStatus: response.status
      });
    }

    const routes = (data.routes || []).map((route, index) => {
      const summary = route.summary || {};

      return {
        id: index,
        distanceMeters: summary.lengthInMeters,
        travelTimeSeconds: summary.travelTimeInSeconds,
        trafficDelaySeconds: summary.trafficDelayInSeconds,
        noTrafficTravelTimeSeconds:
          summary.noTrafficTravelTimeInSeconds,
        liveTrafficTravelTimeSeconds:
          summary.liveTrafficIncidentsTravelTimeInSeconds,
        points: (route.legs || []).flatMap(leg =>
          (leg.points || []).map(point => ({
            lat: point.latitude,
            lng: point.longitude
          }))
        ),
        trafficSections: (route.sections || [])
          .filter(section => section.sectionType === 'TRAFFIC')
          .map(section => ({
            startPointIndex: section.startPointIndex,
            endPointIndex: section.endPointIndex,
            effectiveSpeedInKmh: section.effectiveSpeedInKmh,
            delayInSeconds: section.delayInSeconds,
            magnitudeOfDelay: section.magnitudeOfDelay
          }))
      };
    });

    res.json({ routes });
  } catch (error) {
    console.error('Traffic routing error:', error.message);
    res.status(500).json({
      error: 'Could not calculate traffic-aware routes.'
    });
  }
});

app.get('/api/traffic-tiles/:z/:x/:y', requireAuth, async (req, res) => {
  try {
    const { z, x, y } = req.params;
    const valid = value => /^\d+$/.test(value);

    if (![z, x, y].every(valid)) {
      return res.status(400).send('Invalid tile coordinates.');
    }

    const zoom = Number(z);
    const tileX = Number(x);
    const tileY = Number(y);

    if (
      zoom > 22 ||
      tileX >= 2 ** zoom ||
      tileY >= 2 ** zoom
    ) {
      return res.status(400).send('Tile coordinates out of range.');
    }

    const key = process.env.TOMTOM_API_KEY;

    if (!key) {
      return res.status(500).send('TomTom API key is missing.');
    }

    const url = new URL(
      `https://api.tomtom.com/traffic/map/4/tile/flow/relative0/${zoom}/${tileX}/${tileY}.png`
    );
    url.searchParams.set('key', key);

    const response = await fetch(url);

    if (!response.ok) {
      console.error('TomTom tile error:', response.status);
      return res.status(502).send('Traffic tiles unavailable.');
    }

    res.set('Content-Type', 'image/png');
    res.set('Cache-Control', 'private, max-age=60');
    res.send(Buffer.from(await response.arrayBuffer()));
  } catch (error) {
    console.error('Traffic tile request failed:', error.message);
    res.status(502).send('Could not load traffic tiles.');
  }
});

 // LOAD EMERGENCY FACILITIES FROM MYSQL
app.get('/api/facilities', requireAuth, async (req, res) => {
  try {
    const lat = Number(req.query.lat);
    const lng = Number(req.query.lng);

    if (
      !Number.isFinite(lat) ||
      !Number.isFinite(lng) ||
      lat < -90 || lat > 90 ||
      lng < -180 || lng > 180
    ) {
      return res.status(400).json({
        error: 'Valid latitude and longitude are required.'
      });
    }

    const [rows] = await pool.execute(
      `SELECT id, name, facility_type, latitude, longitude
       FROM emergency_facilities
       WHERE latitude BETWEEN ? AND ?
         AND longitude BETWEEN ? AND ?
       LIMIT 1000`,
      [
        lat - 0.1,
        lat + 0.1,
        lng - 0.1,
        lng + 0.1
      ]
    );

    res.json({
      facilities: rows
    });
  } catch (error) {
    console.error('Facility loading error:', error);
    res.status(500).json({
      error: 'Could not load emergency facilities.'
    });
  }
});


server.listen(PORT, () => console.log(`Emergency Route Priority System running at http://localhost:${PORT}`));
