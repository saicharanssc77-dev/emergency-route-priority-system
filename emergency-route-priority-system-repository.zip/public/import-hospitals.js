
require("dotenv").config();

const fs = require("fs");
const path = require("path");
const os = require("os");
const mysql = require("mysql2/promise");

// Find the downloaded GeoJSON file
const possiblePaths = [
  path.join(__dirname, "export.geojson"),
  path.join(os.homedir(), "Downloads", "export.geojson"),
  path.join(__dirname, "bengaluru_hospitals.geojson"),
  path.join(
    os.homedir(),
    "Downloads",
    "bengaluru_hospitals.geojson"
  )
];

async function importHospitals() {
  let connection;

  try {
    console.log("Searching for hospital GeoJSON...");

    const filePath = possiblePaths.find(file =>
      fs.existsSync(file)
    );

    if (!filePath) {
      throw new Error(
        "Hospital GeoJSON not found in project folder or Downloads."
      );
    }

    console.log("File found:", filePath);

    const geojson = JSON.parse(
      fs.readFileSync(filePath, "utf8")
    );

    if (!Array.isArray(geojson.features)) {
      throw new Error("Invalid GeoJSON FeatureCollection.");
    }

    connection = await mysql.createConnection({
      host: process.env.DB_HOST || "localhost",
      user: process.env.DB_USER || "root",
      password: process.env.DB_PASSWORD || "",
      database:
        process.env.DB_NAME ||
        process.env.DB_DATABASE ||
        "emergency_route_priority"
    });

    console.log("Connected to MySQL.");
    console.log(
      "Total GeoJSON records:",
      geojson.features.length
    );

    let inserted = 0;
    let skipped = 0;
    let duplicates = 0;

    for (const feature of geojson.features) {
      const properties = feature.properties || {};
      const geometry = feature.geometry || {};

      const name = String(
        properties.name || ""
      ).trim();

      const coordinates = geometry.coordinates || [];

      const lng = Number(coordinates[0]);
      const lat = Number(coordinates[1]);

      // Only named hospitals with valid coordinates
      if (
        properties.amenity !== "hospital" ||
        geometry.type !== "Point" ||
        !name ||
        !Number.isFinite(lat) ||
        !Number.isFinite(lng) ||
        lat < -90 ||
        lat > 90 ||
        lng < -180 ||
        lng > 180
      ) {
        skipped++;
        continue;
      }

      // Exclude obvious animal/veterinary facilities
      const lowerName = name.toLowerCase();

      if (
        /veterinary|animal hospital|pet hospital|vet hospital/.test(
          lowerName
        ) ||
        properties.healthcare === "veterinary"
      ) {
        skipped++;
        continue;
      }

      // Check for an existing matching record
      const [existing] = await connection.execute(
        `SELECT id
         FROM emergency_facilities
         WHERE facility_type = 'hospital'
           AND name = ?
           AND ABS(latitude - ?) < 0.0001
           AND ABS(longitude - ?) < 0.0001
         LIMIT 1`,
        [name, lat, lng]
      );

      if (existing.length > 0) {
        duplicates++;
        continue;
      }

      // Insert hospital into MySQL
      await connection.execute(
        `INSERT INTO emergency_facilities
          (name, facility_type, latitude, longitude, source)
         VALUES (?, 'hospital', ?, ?, ?)`,
        [
          name.substring(0, 255),
          lat,
          lng,
          "OpenStreetMap Hospital"
        ]
      );

      inserted++;
    }

    console.log("\nIMPORT COMPLETED");
    console.log("Inserted:", inserted);
    console.log("Duplicates:", duplicates);
    console.log("Skipped:", skipped);

    console.log(
      "\nHospital records are now available to the map API."
    );

  } catch (error) {
    console.error("Import failed:", error.message);
    process.exitCode = 1;
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

importHospitals();
