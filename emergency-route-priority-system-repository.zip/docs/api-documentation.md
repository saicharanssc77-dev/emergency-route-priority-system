# API Documentation

All paths below are implemented in `server.js`. Authenticated routes use the session established by `/api/login`.

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Check server and database availability |
| POST | `/api/login` | Authenticate a user |
| POST | `/api/logout` | End the current session |
| GET | `/api/me` | Return the current session user |
| GET | `/api/alerts` | List recent alerts |
| POST | `/api/alerts` | Create an emergency alert (driver/admin role) |
| PATCH | `/api/alerts/:id/status` | Update an alert status (role-protected) |
| GET | `/api/admin/summary` | Retrieve administrator summary |
| GET | `/api/routes/traffic` | Request a traffic-aware route |
| GET | `/api/traffic-tiles/:z/:x/:y` | Proxy traffic map tiles |
| GET | `/api/facilities` | Retrieve nearby emergency facilities |

## Real-time events
The application uses Socket.IO for alert-change notifications. Refer to the event handlers in `server.js` and `public/app.js` for the exact event names and payload shape.

## Notes
The API key for TomTom is read from the server environment. Do not place it in browser code or commit it to the repository.
