# Project Overview

## Problem statement
Emergency response can be delayed when drivers, traffic personnel, and response coordinators lack a shared view of an incident and its destination.

## Proposed system
The Emergency Route Priority System is a browser-based academic prototype. A driver can use an interactive map, select a destination, and submit an emergency alert. Traffic-police users can view and update alerts. An administrator can inspect summary information.

## User roles
- **Driver:** uses the map and submits emergency alerts.
- **Traffic police:** monitors incoming alerts and updates their status.
- **Administrator:** views system-level summaries.

## Scope
The system demonstrates software-based coordination, map visualization, routing/traffic integration, database persistence, and real-time browser updates. It does not dispatch real vehicles, contact emergency services, or operate traffic lights.
