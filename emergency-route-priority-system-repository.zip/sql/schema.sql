CREATE DATABASE IF NOT EXISTS emergency_route_priority;
USE emergency_route_priority;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  username VARCHAR(60) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('driver','police','admin') NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS alerts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  created_by INT NOT NULL,
  emergency_type ENUM('Ambulance and Medical','Fire and Rescue','Police','Disaster Response','Organ and Blood Transport','Electricity Emergency','Water and Utility Emergency','Animal Rescue') NOT NULL,
  destination VARCHAR(255) NOT NULL,
  latitude DECIMAL(10,7) NOT NULL,
  longitude DECIMAL(10,7) NOT NULL,
  message VARCHAR(500) NOT NULL DEFAULT '',
  status ENUM('New','Acknowledged','Responding','Resolved') NOT NULL DEFAULT 'New',
  assigned_to INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_alert_creator FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_alert_assignee FOREIGN KEY (assigned_to) REFERENCES users(id)
);
