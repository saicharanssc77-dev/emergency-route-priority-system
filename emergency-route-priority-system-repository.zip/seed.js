require('dotenv').config();
const bcrypt = require('bcryptjs');
const mysql = require('mysql2/promise');
(async () => {
  const db = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost', port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || 'root', password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'emergency_route_priority'
  });
  const demoUsers = [
    { name: 'Demo Driver', username: 'driver', password: 'Driver@123', role: 'driver' },
    { name: 'Demo Traffic Police', username: 'police', password: 'Police@123', role: 'police' },
    { name: 'Demo Administrator', username: 'admin', password: 'Admin@123', role: 'admin' }
  ];
  for (const user of demoUsers) {
    const hash = await bcrypt.hash(user.password, 10);
    await db.execute('INSERT INTO users (name, username, password_hash, role) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE name=VALUES(name), password_hash=VALUES(password_hash), role=VALUES(role)', [user.name, user.username, hash, user.role]);
  }
  await db.end();
  console.log('Demo accounts ready: driver / Driver@123, police / Police@123, admin / Admin@123');
})().catch(e => { console.error('Seed failed:', e.message); process.exit(1); });
