# Methodology

1. **Requirement analysis:** identify the driver, traffic-police, and administrator workflows.
2. **Interface development:** build the browser interface with HTML, CSS, JavaScript, and Leaflet.
3. **Location and map integration:** use browser geolocation where permitted and display the map with Leaflet/OpenStreetMap.
4. **Routing and traffic integration:** request route and traffic information through backend endpoints using the configured TomTom API key.
5. **Backend development:** implement Express endpoints, session-based login, role checks, and validation.
6. **Database design:** store user accounts and emergency alerts in MySQL.
7. **Real-time communication:** use Socket.IO to notify connected browser sessions when alert data changes.
8. **Demonstration and testing:** run the application locally, test each role, submit an alert, and verify status updates in another browser session.

## Evaluation checklist
- Can each demo role sign in?
- Can the driver select a destination and submit a valid alert?
- Is the alert saved in MySQL?
- Can the police role change the alert status?
- Do connected sessions receive alert updates?
- Does the map handle denied location permission or unavailable external services gracefully?
