# Database Design

The schema in `sql/schema.sql` creates the `emergency_route_priority` database and two tables.

## `users`
| Column | Purpose |
|---|---|
| `id` | Primary key |
| `name` | Display name |
| `username` | Unique login name |
| `password_hash` | Bcrypt password hash |
| `role` | `driver`, `police`, or `admin` |
| `created_at` | Account creation timestamp |

## `alerts`
| Column | Purpose |
|---|---|
| `id` | Primary key |
| `created_by` | User who created the alert |
| `emergency_type` | Emergency category |
| `destination` | Destination label |
| `latitude`, `longitude` | Destination coordinates |
| `message` | Optional alert message |
| `status` | New, Acknowledged, Responding, or Resolved |
| `assigned_to` | Optional assigned police user |
| `created_at`, `updated_at` | Timestamps |

Foreign keys connect alert creators and assignees to `users`. The seed script inserts or updates the three demonstration accounts.
