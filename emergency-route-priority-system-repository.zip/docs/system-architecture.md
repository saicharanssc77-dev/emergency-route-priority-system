# System Architecture

```text
Browser (Leaflet UI)
  | HTTP / JSON
  v
Node.js + Express (server.js) ---- TomTom routing and traffic services
  |                                  |
  | SQL                              | traffic tiles / route response
  v                                  v
MySQL database                   Browser map
  ^
  | Socket.IO events
  |
Connected browser sessions
```

## Main components
- `public/index.html`: page structure and role views.
- `public/styles.css`: layout and visual styling.
- `public/app.js`: map, browser geolocation, user interactions, API requests, and Socket.IO client behavior.
- `server.js`: Express routes, session authentication, database access, external-service proxying, and Socket.IO server.
- `sql/schema.sql`: database and table definitions.
- `seed.js`: creates the demonstration users with hashed passwords.

The browser requests location permission; location availability and accuracy depend on the user's device and browser. The backend keeps the TomTom API key server-side and proxies relevant requests.
