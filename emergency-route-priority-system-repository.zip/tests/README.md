# Tests

No automated test suite is included in this project snapshot. Use the manual role-based workflow in the root README as the current smoke-test procedure. Add automated tests for authentication, authorization, alert validation, database operations, and Socket.IO updates before deployment.
