
const $ = id => document.getElementById(id);

// GLOBAL VARIABLES
let currentUser = null;
let map = null;
let destinationMarker = null;
let currentLocationMarker = null;
let locationAccuracyCircle = null;
let vehicleMarker = null;
let routeLine = null;
let trafficLayer = null;
let hospitalLayer = null;

let selectedPoint = null;
let currentLocation = null;
let routePoints = [];
let simulationTimer = null;
let locationWatchId = null;
let centeredOnLiveLocation = false;
let locationRequestPending = false;
let routeRequestId = 0;
let facilitiesRequestId = 0;
let facilitiesTimer = null;
let facilitiesController = null;

const facilityStyles = {
  hospital: {
    label: "Healthcare Facility",
    color: "#dc2626",
    symbol: "+"
  },
  fire_station: {
    label: "Fire Station",
    color: "#ea580c",
    symbol: "F"
  },
  police: {
    label: "Police Station",
    color: "#2563eb",
    symbol: "P"
  },
  veterinary: {
    label: "Veterinary Clinic",
    color: "#16a34a",
    symbol: "V"
  },
  substation: {
    label: "Electricity Substation",
    color: "#9333ea",
    symbol: "E"
  }
};

// SOCKET CONNECTION
const socket = io();

socket.on("connect", () => {
  if ($("connection")) {
    $("connection").textContent = "Live connection";
    $("connection").classList.add("online");
  }
});

socket.on("disconnect", () => {
  if ($("connection")) {
    $("connection").textContent = "Reconnecting…";
    $("connection").classList.remove("online");
  }
});

socket.on("alerts:changed", () => {
  if (currentUser) refreshDashboard();
});

// API HELPER
async function api(url, options = {}) {
  const response = await fetch(url, {
    credentials: "same-origin",
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {})
    }
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(data.error || "Something went wrong.");
  }

  return data;
}

function show(id, visible = true) {
  const element = $(id);
  if (element) {
    element.classList.toggle("hidden", !visible);
  }
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[char]);
}

function formatDate(value) {
  if (!value) return "—";

  const date = new Date(value);

  return Number.isNaN(date.getTime())
    ? String(value)
    : date.toLocaleString();
}

function statusPill(status) {
  return `<span class="pill status-${escapeHtml(
    String(status).toLowerCase()
  )}">${escapeHtml(status)}</span>`;
}

function setError(id, message = "") {
  if ($(id)) $(id).textContent = message;
}

function setLocationStatus(message) {
  if ($("destinationHint")) {
    $("destinationHint").textContent = message;
  }
}

// LOGIN
$("loginForm").addEventListener("submit", async event => {
  event.preventDefault();
  setError("loginError");

  try {
    const result = await api("/api/login", {
      method: "POST",
      body: JSON.stringify({
        username: $("username").value,
        password: $("password").value
      })
    });

    currentUser = result.user;
    await enterApp();
  } catch (error) {
    setError("loginError", error.message);
  }
});

// LOGOUT
$("logoutBtn").addEventListener("click", async () => {
  try {
    await api("/api/logout", { method: "POST" });
  } catch (error) {
    console.warn("Logout request failed:", error);
  }

  stopSimulation();
  stopLiveLocation();

  routeRequestId++;
  facilitiesRequestId++;

  clearTimeout(facilitiesTimer);

  if (facilitiesController) {
    facilitiesController.abort();
    facilitiesController = null;
  }

  if (map) {
    map.remove();
    map = null;
  }

  currentUser = null;
  currentLocation = null;
  selectedPoint = null;
  centeredOnLiveLocation = false;
  locationRequestPending = false;

  destinationMarker = null;
  currentLocationMarker = null;
  locationAccuracyCircle = null;
  vehicleMarker = null;
  routeLine = null;
  trafficLayer = null;
  hospitalLayer = null;
  routePoints = [];

  show("appView", false);
  show("loginView", true);
  show("logoutBtn", false);
});

$("refreshBtn").addEventListener("click", refreshDashboard);
$("simulateBtn").addEventListener("click", toggleSimulation);

// EMERGENCY TYPE
$("emergencyType").addEventListener("change", () => {
  if (!selectedPoint) {
    setLocationStatus(
      "Select a destination on the map. Emergency facilities are marked in different colors."
    );
  }
});

// SEND EMERGENCY ALERT
$("alertForm").addEventListener("submit", async event => {
  event.preventDefault();

  setError("alertError");
  setError("alertSuccess");

  if (!selectedPoint) {
    setError(
      "alertError",
      "Click the map first to select a destination."
    );
    return;
  }

  try {
    await api("/api/alerts", {
      method: "POST",
      body: JSON.stringify({
        emergencyType: $("emergencyType").value,
        destination: $("destination").value,
        message: $("message").value,
        latitude: selectedPoint.lat,
        longitude: selectedPoint.lng
      })
    });

    setError(
      "alertSuccess",
      "Alert sent successfully. Traffic police can see it on their dashboard."
    );

    $("message").value = "";
    await refreshDashboard();
  } catch (error) {
    setError("alertError", error.message);
  }
});

// ENTER DASHBOARD
async function enterApp() {
  show("loginView", false);
  show("appView", true);
  show("logoutBtn", true);

  $("userName").textContent = currentUser.name;
  $("userRole").textContent = currentUser.role;
  $("userInitial").textContent =
    currentUser.name.charAt(0).toUpperCase();

  $("roleLabel").textContent =
    `${currentUser.role.toUpperCase()} CONTROL PANEL`;

  const roleDetails = {
    driver: [
      "Driver dashboard",
      "Plan a route and report a traffic obstruction."
    ],
    police: [
      "Traffic police dashboard",
      "Review emergency alerts and coordinate response."
    ],
    admin: [
      "Administrator dashboard",
      "Review system activity, alerts, and demo users."
    ]
  };

  const details =
    roleDetails[currentUser.role] || roleDetails.driver;

  $("welcomeTitle").textContent = details[0];
  $("welcomeText").textContent = details[1];

  show("driverPanel", currentUser.role === "driver");
  show("policePanel", currentUser.role === "police");
  show("adminPanel", currentUser.role === "admin");

  await refreshDashboard();

  if (currentUser.role === "driver") {
    setTimeout(() => {
      if (!currentUser || currentUser.role !== "driver") return;

      initMap();

      if (map) map.invalidateSize();
    }, 300);
  }
}

// ===========================================
// MAP INITIALIZATION
// ===========================================

function initMap() {
  if (map) {
    map.invalidateSize();
    return;
  }

  if (!window.L) {
    setLocationStatus(
      "Map library failed to load. Check your internet connection."
    );
    return;
  }

  // DEFAULT MAP LOCATION: BENGALURU
  map = L.map("map").setView([12.9716, 77.5946], 12);

  // OPENSTREETMAP BASE MAP
  L.tileLayer(
    "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    {
      maxZoom: 19,
      attribution: "&copy; OpenStreetMap contributors"
    }
  ).addTo(map);

  // MAP PANES
  map.createPane("routePane");
  map.getPane("routePane").style.zIndex = 500;

  map.createPane("trafficPane");
  map.getPane("trafficPane").style.zIndex = 450;

  // TOMTOM TRAFFIC OVERLAY
  trafficLayer = L.tileLayer(
    "/api/traffic-tiles/{z}/{x}/{y}",
    {
      pane: "trafficPane",
      maxZoom: 22,
      opacity: 0.55,
      attribution: "&copy; TomTom Traffic"
    }
  );

  trafficLayer.on("tileerror", () => {
    console.warn("TomTom traffic tiles failed to load.");
  });

  trafficLayer.addTo(map);

  // EMERGENCY FACILITY MARKER LAYER
  hospitalLayer = L.layerGroup().addTo(map);

  // LOAD MYSQL FACILITIES IMMEDIATELY
  scheduleFacilitiesLoad(0);

  // RELOAD FACILITIES WHEN MAP MOVES
  map.on("moveend", () => {
    scheduleFacilitiesLoad(250);
  });

  // START LIVE LOCATION
  startLiveLocation();

  // DESTINATION SELECTION
  map.on("click", async event => {
    selectedPoint = {
      lat: event.latlng.lat,
      lng: event.latlng.lng
    };

    $("destination").value =
      `${event.latlng.lat.toFixed(5)}, ${event.latlng.lng.toFixed(5)}`;

    if (destinationMarker) {
      destinationMarker.remove();
    }

    destinationMarker = L.marker(event.latlng)
      .addTo(map)
      .bindPopup("Selected destination")
      .openPopup();

    stopSimulation();

    if (!currentLocation) {
      $("simulateBtn").disabled = true;

      setLocationStatus(
        "Destination selected. Waiting for your live location before calculating the route."
      );
      return;
    }

    setLocationStatus("Finding a road route…");
    await drawRoute(event.latlng);
  });
}

// ===========================================
// LIVE LOCATION
// ===========================================

function stopLiveLocation() {
  if (locationWatchId !== null && navigator.geolocation) {
    navigator.geolocation.clearWatch(locationWatchId);
    locationWatchId = null;
  }

  locationRequestPending = false;
}

function startLiveLocation() {
  if (!map) return;

  if (!window.isSecureContext) {
    setLocationStatus(
      "Location requires a secure connection. Open http://localhost:3000."
    );
    return;
  }

  if (!navigator.geolocation) {
    setLocationStatus(
      "Your browser does not support location services."
    );
    return;
  }

  if (locationWatchId !== null || locationRequestPending) {
    return;
  }

  locationRequestPending = true;

  setLocationStatus(
    "Detecting your live location. Please allow location access in Chrome."
  );

  const options = {
    enableHighAccuracy: false,
    maximumAge: 10000,
    timeout: 30000
  };

  navigator.geolocation.getCurrentPosition(
    position => {
      locationRequestPending = false;
      updateLiveLocation(position);
      watchLiveLocation();
    },
    error => {
      locationRequestPending = false;
      handleLocationError(error);

      if (error.code !== 1) {
        watchLiveLocation();
      }
    },
    options
  );
}

function watchLiveLocation() {
  if (!navigator.geolocation || !map) return;
  if (locationWatchId !== null) return;

  locationWatchId = navigator.geolocation.watchPosition(
    position => {
      updateLiveLocation(position);
    },
    error => {
      handleLocationError(error);

      if (error.code === 1) {
        stopLiveLocation();
      }
    },
    {
      enableHighAccuracy: false,
      maximumAge: 5000,
      timeout: 30000
    }
  );
}

function updateLiveLocation(position) {
  if (!map || !currentUser || currentUser.role !== "driver") {
    return;
  }

  const lat = position.coords.latitude;
  const lng = position.coords.longitude;
  const accuracy = position.coords.accuracy;

  if (
    !Number.isFinite(lat) ||
    !Number.isFinite(lng) ||
    !Number.isFinite(accuracy)
  ) {
    return;
  }

  const firstFix = currentLocation === null;

  currentLocation = { lat, lng };

  // LIVE LOCATION MARKER
  if (!currentLocationMarker) {
    currentLocationMarker = L.circleMarker([lat, lng], {
      radius: 10,
      color: "#ffffff",
      weight: 3,
      fillColor: "#2563eb",
      fillOpacity: 1,
      bubblingMouseEvents: false
    })
      .addTo(map)
      .bindPopup("Your live location");
  } else {
    currentLocationMarker.setLatLng([lat, lng]);
  }

  // LOCATION ACCURACY CIRCLE
  if (!locationAccuracyCircle) {
    locationAccuracyCircle = L.circle([lat, lng], {
      radius: accuracy,
      color: "#2563eb",
      weight: 1,
      opacity: 0.45,
      fillColor: "#2563eb",
      fillOpacity: 0.08,
      interactive: false
    }).addTo(map);
  } else {
    locationAccuracyCircle.setLatLng([lat, lng]);
    locationAccuracyCircle.setRadius(accuracy);
  }

  if (!centeredOnLiveLocation) {
    map.setView([lat, lng], 16);

    currentLocationMarker.openPopup();

    centeredOnLiveLocation = true;

    // LOAD FACILITIES NEAR LIVE LOCATION
    scheduleFacilitiesLoad(0);
  }

  console.log("Live location received:", {
    latitude: lat,
    longitude: lng,
    accuracy: Math.round(accuracy)
  });

  if (!selectedPoint) {
    setLocationStatus(
      `Live location detected (accuracy: ±${Math.round(accuracy)} m). ` +
      "Click the map to select your destination."
    );
  }

  if (firstFix && selectedPoint) {
    drawRoute(
      L.latLng(selectedPoint.lat, selectedPoint.lng)
    );
  }
}

function handleLocationError(error) {
  console.error("Geolocation error:", {
    code: error.code,
    message: error.message
  });

  const messages = {
    1: "Location permission denied. Allow location access in Chrome and refresh.",
    2: "Location unavailable. Enable Windows location services and check your internet connection.",
    3: "Location request timed out. Check your device location settings."
  };

  if (!currentLocation) {
    setLocationStatus(
      messages[error.code] ||
      "Unable to detect your current location."
    );
  }
}

// ===========================================
// EMERGENCY FACILITIES FROM MYSQL
// NO OVERPASS API REQUIRED
// ===========================================

function scheduleFacilitiesLoad(delay = 0) {
  clearTimeout(facilitiesTimer);

  facilitiesTimer = setTimeout(() => {
    loadNearbyFacilities();
  }, delay);
}

function renderEmergencyFacilities(facilities) {
  if (!map || !hospitalLayer) return;

  hospitalLayer.clearLayers();

  const counts = {};

  for (const facility of facilities) {
    const lat = Number(facility.latitude);
    const lng = Number(facility.longitude);
    const type = facility.facility_type;

    const service = facilityStyles[type];

    if (
      !Number.isFinite(lat) ||
      !Number.isFinite(lng) ||
      !service
    ) {
      continue;
    }

    const label = service.label;
    const name = facility.name || label;

    const icon = L.divIcon({
      className: "emergency-service-icon",
      html: `
        <div style="
          width:28px;
          height:28px;
          border-radius:50%;
          background:${service.color};
          color:white;
          border:2px solid white;
          display:flex;
          align-items:center;
          justify-content:center;
          font-weight:800;
          font-size:17px;
          box-shadow:0 2px 6px rgba(0,0,0,0.3);
        ">
          ${service.symbol}
        </div>
      `,
      iconSize: [32, 32],
      iconAnchor: [16, 16]
    });

    L.marker([lat, lng], {
      icon,
      bubblingMouseEvents: false
    })
      .bindPopup(`
        <strong>${escapeHtml(name)}</strong>
        <br>
        ${escapeHtml(label)}
      `)
      .addTo(hospitalLayer);

    counts[type] = (counts[type] || 0) + 1;
  }

  console.log(
    "MySQL emergency facility markers loaded:",
    counts
  );
}

async function loadNearbyFacilities() {
  if (!map || !hospitalLayer || !currentUser) {
    return;
  }

  const requestId = ++facilitiesRequestId;

  // USE THE CURRENT MAP CENTER
  const center = map.getCenter();

  // CANCEL PREVIOUS REQUEST
  if (facilitiesController) {
    facilitiesController.abort();
  }

  const controller = new AbortController();
  facilitiesController = controller;

  const params = new URLSearchParams({
    lat: String(center.lat),
    lng: String(center.lng)
  });

  try {
    // READ SAVED FACILITIES DIRECTLY FROM MYSQL API
    const response = await fetch(
      `/api/facilities?${params.toString()}`,
      {
        credentials: "same-origin",
        signal: controller.signal
      }
    );

    if (!response.ok) {
      throw new Error(
        `Facility API returned HTTP ${response.status}`
      );
    }

    const data = await response.json();

    if (!Array.isArray(data.facilities)) {
      throw new Error(
        "Facility API returned invalid data"
      );
    }

    if (
      requestId !== facilitiesRequestId ||
      !map
    ) {
      return;
    }

    renderEmergencyFacilities(data.facilities);

    console.log(
      `Loaded ${data.facilities.length} facilities from MySQL.`
    );

    if (!data.facilities.length) {
      console.info(
        "No saved facilities near this map area."
      );
    }

  } catch (error) {
    if (error.name !== "AbortError") {
      console.warn(
        "Could not load emergency facilities:",
        error.message
      );
    }
  } finally {
    if (facilitiesController === controller) {
      facilitiesController = null;
    }
  }
}

// ===========================================
// TOMTOM TRAFFIC-AWARE ROUTE PLANNING
// ===========================================

async function drawRoute(destination) {
  if (!map) return;

  if (!currentLocation) {
    setLocationStatus(
      "Waiting for live location. A route cannot be calculated yet."
    );
    return;
  }

  const requestId = ++routeRequestId;

  const start = L.latLng(
    currentLocation.lat,
    currentLocation.lng
  );

  stopSimulation();

  if (routeLine) {
    routeLine.remove();
  }

  routeLine = L.featureGroup().addTo(map);
  routePoints = [];

  $("simulateBtn").disabled = true;

  const hint = $("destinationHint");

  hint.textContent = "Calculating traffic-aware routes...";

  try {
    const params = new URLSearchParams({
      originLat: String(start.lat),
      originLng: String(start.lng),
      destLat: String(destination.lat),
      destLng: String(destination.lng)
    });

    const response = await fetch(
      `/api/routes/traffic?${params.toString()}`
    );

    const data = await response.json();

    if (
      requestId !== routeRequestId ||
      !map
    ) {
      return;
    }

    if (!response.ok) {
      throw new Error(
        data.error || "Traffic routing failed."
      );
    }

    if (!data.routes || !data.routes.length) {
      throw new Error("No routes were returned.");
    }

    const routes = data.routes;
    let selectedIndex = 0;

    function selectRoute(index) {
      selectedIndex = index;

      routeLine.clearLayers();

      routes.forEach((route, routeIndex) => {
        const points = route.points.map(point => [
          point.lat,
          point.lng
        ]);

        if (points.length < 2) return;

        // ALTERNATIVE ROUTES
        if (routeIndex !== selectedIndex) {
          L.polyline(points, {
            color: "#64748b",
            weight: 4,
            opacity: 0.8,
            dashArray: "7 6",
            bubblingMouseEvents: false
          })
            .addTo(routeLine)
            .on("click", event => {
              L.DomEvent.stopPropagation(
                event.originalEvent
              );

              selectRoute(routeIndex);
            });

          return;
        }

        routePoints = points;

        // WHITE ROUTE OUTLINE
        L.polyline(points, {
          color: "#ffffff",
          weight: 11,
          opacity: 1,
          bubblingMouseEvents: false
        }).addTo(routeLine);

        // BLUE SELECTED ROUTE
        L.polyline(points, {
          color: "#245fe5",
          weight: 7,
          opacity: 1,
          lineCap: "round",
          lineJoin: "round",
          bubblingMouseEvents: false
        }).addTo(routeLine);

        // TRAFFIC CONGESTION SECTIONS
        const sections =
          route.trafficSections || [];

        sections.forEach(section => {
          const first = Math.max(
            0,
            Number(section.startPointIndex) || 0
          );

          const last = Math.min(
            points.length - 1,
            Number(section.endPointIndex) || 0
          );

          if (last <= first) return;

          const magnitude = Number(
            section.magnitudeOfDelay
          );

          if (
            !Number.isFinite(magnitude) ||
            magnitude < 3
          ) {
            return;
          }

          const segment = points.slice(
            first,
            last + 1
          );

          if (segment.length < 2) return;

          L.polyline(segment, {
            color: "#dc2626",
            weight: 8,
            opacity: 1,
            lineCap: "round",
            lineJoin: "round",
            bubblingMouseEvents: false
          }).addTo(routeLine);
        });
      });

      const route = routes[selectedIndex];

      const distance =
        (route.distanceMeters / 1000).toFixed(1);

      const minutes =
        Math.round(route.travelTimeSeconds / 60);

      const delay =
        Math.max(0, route.trafficDelaySeconds || 0);

      const delayMinutes =
        Math.round(delay / 60);

      hint.textContent =
        `Route ${selectedIndex + 1} of ${routes.length} · ` +
        `${distance} km · ${minutes} min with traffic · ` +
        `Reported delay: ${delayMinutes} min. ` +
        "Grey dashed lines are alternatives. Select a line to compare.";

      $("simulateBtn").disabled =
        routePoints.length < 2;
    }

    selectRoute(0);

    const bounds = routeLine.getBounds();

    if (bounds.isValid()) {
      map.fitBounds(bounds, {
        padding: [25, 25]
      });
    }

  } catch (error) {
    if (
      requestId !== routeRequestId ||
      !map
    ) {
      return;
    }

    console.error(
      "Traffic routing error:",
      error
    );

    routeLine.clearLayers();
    routePoints = [];

    $("simulateBtn").disabled = true;

    hint.textContent =
      `Traffic-aware routing unavailable: ${error.message} ` +
      "Please try again. No live-traffic route is being shown.";
  }
}

// ===========================================
// SIMULATED EMERGENCY VEHICLE
// ===========================================

function toggleSimulation() {
  if (simulationTimer) {
    stopSimulation();
    return;
  }

  if (routePoints.length < 2) return;

  let index = 0;

  if (vehicleMarker) {
    vehicleMarker.remove();
  }

  vehicleMarker = L.circleMarker(
    routePoints[0],
    {
      radius: 8,
      color: "#ffffff",
      weight: 2,
      fillColor: "#dc2626",
      fillOpacity: 1
    }
  )
    .addTo(map)
    .bindPopup("Simulated emergency vehicle");

  $("simulateBtn").textContent =
    "Ⅱ Stop simulation";

  simulationTimer = setInterval(() => {
    index++;

    if (index >= routePoints.length) {
      stopSimulation();

      vehicleMarker.setPopupContent(
        "Simulation complete"
      );

      return;
    }

    vehicleMarker.setLatLng(
      routePoints[index]
    );
  }, Math.max(
    40,
    Math.min(150, 7000 / routePoints.length)
  ));
}

function stopSimulation() {
  if (simulationTimer) {
    clearInterval(simulationTimer);
  }

  simulationTimer = null;

  if ($("simulateBtn")) {
    $("simulateBtn").textContent =
      "▶ Simulate movement";
  }
}

// ===========================================
// DASHBOARD REFRESH
// ===========================================

async function refreshDashboard() {
  if (!currentUser) return;

  try {
    const { alerts } = await api("/api/alerts");

    $("totalAlerts").textContent = alerts.length;

    $("newAlerts").textContent =
      alerts.filter(
        a => a.status === "New"
      ).length;

    $("respondingAlerts").textContent =
      alerts.filter(
        a => a.status === "Responding"
      ).length;

    $("resolvedAlerts").textContent =
      alerts.filter(
        a => a.status === "Resolved"
      ).length;

    $("historyCount").textContent =
      `${alerts.length} RECORDS`;

    $("historyTable").innerHTML = alerts.length
      ? alerts.map(a => `
        <tr>
          <td><strong>#${a.id}</strong></td>
          <td>${escapeHtml(a.emergency_type)}</td>
          <td>
            ${escapeHtml(a.destination)}<br>
            <small>
              ${Number(a.latitude).toFixed(4)},
              ${Number(a.longitude).toFixed(4)}
            </small>
          </td>
          <td>${escapeHtml(a.driver_name)}</td>
          <td>${escapeHtml(formatDate(a.created_at))}</td>
          <td>${statusPill(a.status)}</td>
        </tr>
      `).join("")
      : '<tr><td colspan="6" class="empty">No alerts have been reported yet.</td></tr>';

    if (currentUser.role === "police") {
      renderPoliceTable(alerts);
    }

    if (currentUser.role === "admin") {
      await loadAdminSummary();
    }

  } catch (error) {
    console.error(
      "Dashboard refresh failed:",
      error
    );
  }
}

// ===========================================
// POLICE DASHBOARD
// ===========================================

function renderPoliceTable(alerts) {
  $("policeTable").innerHTML = alerts.length
    ? alerts.map(a => `
      <tr>
        <td><strong>#${a.id}</strong></td>
        <td>${escapeHtml(a.emergency_type)}</td>
        <td>
          ${escapeHtml(a.destination)}<br>
          <small>
            ${Number(a.latitude).toFixed(4)},
            ${Number(a.longitude).toFixed(4)}
          </small>
        </td>
        <td>${escapeHtml(a.driver_name)}</td>
        <td>${escapeHtml(formatDate(a.created_at))}</td>
        <td>${statusPill(a.status)}</td>
        <td>
          <select
            class="action-select"
            data-alert-id="${a.id}"
            aria-label="Update alert status"
          >
            <option value="New"
              ${a.status === "New" ? "selected" : ""}>
              New
            </option>
            <option value="Acknowledged"
              ${a.status === "Acknowledged" ? "selected" : ""}>
              Acknowledged
            </option>
            <option value="Responding"
              ${a.status === "Responding" ? "selected" : ""}>
              Responding
            </option>
            <option value="Resolved"
              ${a.status === "Resolved" ? "selected" : ""}>
              Resolved
            </option>
          </select>
        </td>
      </tr>
    `).join("")
    : '<tr><td colspan="7" class="empty">No emergency alerts yet.</td></tr>';

  document.querySelectorAll(
    "[data-alert-id]"
  ).forEach(select => {
    select.addEventListener(
      "change",
      async () => {
        select.disabled = true;

        try {
          await api(
            `/api/alerts/${select.dataset.alertId}/status`,
            {
              method: "PATCH",
              body: JSON.stringify({
                status: select.value
              })
            }
          );

          await refreshDashboard();
        } catch (error) {
          alert(error.message);
          select.disabled = false;
        }
      }
    );
  });
}

// ===========================================
// ADMIN SUMMARY
// ===========================================

async function loadAdminSummary() {
  try {
    const data = await api("/api/admin/summary");

    const max = Math.max(
      1,
      ...data.byType.map(
        item => Number(item.count)
      )
    );

    $("typeSummary").innerHTML =
      data.byType.length
        ? data.byType.map(item => `
          <div class="summary-item">
            <span>
              ${escapeHtml(item.type)}
            </span>
            <strong>${item.count}</strong>
            <div class="summary-track">
              <div
                class="summary-fill"
                style="width:${Number(item.count) / max * 100}%"
              ></div>
            </div>
          </div>
        `).join("")
        : '<p class="muted">No category data yet.</p>';

    $("usersTable").innerHTML =
      data.users.map(user => `
        <tr>
          <td>${escapeHtml(user.name)}</td>
          <td>${escapeHtml(user.username)}</td>
          <td>${escapeHtml(user.role)}</td>
        </tr>
      `).join("");

  } catch (error) {
    console.error(
      "Admin summary failed:",
      error
    );
  }
}

// ===========================================
// RESTORE LOGIN SESSION
// ===========================================

(async function boot() {
  try {
    const { user } = await api("/api/me");

    if (user) {
      currentUser = user;
      await enterApp();
    }
  } catch (error) {
    // Keep login screen visible.
  }
})();

// ===========================================
// FACILITY TYPE FOR EACH EMERGENCY
// ===========================================

function getNearbyFacilityType(service) {
  const facilityTypes = {
    "Ambulance and Medical": "hospital",
    "Animal Rescue": "veterinary",
    "Fire and Rescue": "fire_station",
    "Police": "police",
    "Disaster Response": "hospital",
    "Organ and Blood Transport": "hospital",
    "Electricity Emergency": "utility",
    "Water and Utility Emergency": "utility"
  };

  return facilityTypes[service] || "hospital";
}
