
require("dotenv").config();

const fs = require("fs");
const path = require("path");
const os = require("os");
const mysql = require("mysql2/promise");

const FILE_NAME = "bengaluru_health_facilities.geojson";

function findGeoJSONFile() {
  const possiblePaths = [
    path.join(__dirname, FILE_NAME),
    path.join(os.homedir(), "Downloads", FILE_NAME),
    path.join(__dirname, "..", FILE_NAME),
    path.join(
      process.env.USERPROFILE || os.homedir(),
      "Downloads",
      FILE_NAME
    )
  ];

  // Check common locations first
  for (const filePath of possiblePaths) {
    if (fs.existsSync(filePath)) {
      return filePath;
    }
  }

  // Find files such as bengaluru_health_facilities (1).geojson
  const folders = [
    __dirname,
    path.join(os.homedir(), "Downloads"),
    path.join(__dirname, "..")
  ];

  for (const folder of folders) {
    if (!fs.existsSync(folder)) continue;

    const files = fs.readdirSync(folder);

    const match = files.find(file =>
      file.toLowerCase().startsWith(
        "bengaluru_health_facilities"
      ) &&
      file.toLowerCase().endsWith(".geojson")
    );

    if (match) {
      return path.join(folder, match);
    }
  }

  throw new Error(
    "GeoJSON file not found. Please download bengaluru_health_facilities.geojson."
  );
}

async function importFacilities() {
  let connection;

  try {
    console.log("Searching for Bengaluru GeoJSON file...");

    const filePath = findGeoJSONFile();

    console.log("File found:", filePath);

    const data = JSON.parse(
      fs.readFileSync(filePath, "utf8")
    );

    if (!Array.isArray(data.features)) {
      throw new Error(
        "Invalid GeoJSON: features array missing."
      );
    }

    connection = await mysql.createConnection({
      host: process.env.DB_HOST || "localhost",
      port: Number(process.env.DB_PORT || 3306),
      user: process.env.DB_USER || "root",
      password: process.env.DB_PASSWORD || "",
      database:
        process.env.DB_NAME || "emergency_route_priority"
    });

    console.log("Connected to MySQL.");
    console.log(
      "Found",
      data.features.length,
      "healthcare records."
    );

    let inserted = 0;
    let skipped = 0;

    for (const feature of data.features) {
      const coordinates = feature.geometry?.coordinates;
      const properties = feature.properties || {};

      if (
        feature.geometry?.type !== "Point" ||
        !Array.isArray(coordinates)
      ) {
        skipped++;
        continue;
      }

      const longitude = Number(coordinates[0]);
      const latitude = Number(coordinates[1]);

      if (
        !Number.isFinite(latitude) ||
        !Number.isFinite(longitude) ||
        latitude < -90 ||
        latitude > 90 ||
        longitude < -180 ||
        longitude > 180
      ) {
        skipped++;
        continue;
      }

      const facilityName = String(
        properties.name ||
        properties.Name ||
        "Unnamed Healthcare Facility"
      ).trim();

      const facilitySubtype = String(
        properties.type ||
        properties.Type ||
        "Healthcare"
      ).trim();

      const name = `${facilityName} (${facilitySubtype})`;

      // Existing database category for healthcare markers
      const facilityType = "hospital";

      const [existing] = await connection.execute(
        `SELECT id
         FROM emergency_facilities
         WHERE facility_type = ?
           AND ABS(latitude - ?) < 0.000001
           AND ABS(longitude - ?) < 0.000001
         LIMIT 1`,
        [facilityType, latitude, longitude]
      );

      if (existing.length > 0) {
        skipped++;
        continue;
      }

      await connection.execute(
        `INSERT INTO emergency_facilities
         (name, facility_type, latitude, longitude, source)
         VALUES (?, ?, ?, ?, ?)`,
        [
          name,
          facilityType,
          latitude,
          longitude,
          "NIC HealthGIS"
        ]
      );

      inserted++;
    }

    console.log("----------------------------");
    console.log("Import completed!");
    console.log("Inserted:", inserted);
    console.log("Skipped:", skipped);
    console.log("----------------------------");

  } catch (error) {
    console.error("Import failed:", error.message);
    process.exitCode = 1;
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

importFacilities();
