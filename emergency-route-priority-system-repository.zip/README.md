# Emergency Route Priority System

A college-level full-stack prototype demonstrating emergency route planning and coordination between drivers, traffic police, and administrators.

## Features present in this codebase
- Role-based login for driver, traffic police, and administrator.
- Interactive Leaflet map with browser geolocation support for the driver's current location.
- Route calculation and traffic tile proxy endpoints backed by the TomTom API.
- Emergency-facility lookup endpoint and map markers.
- Emergency alerts stored in MySQL.
- Socket.IO events for alert updates across connected browser sessions.
- Police workflow for changing alert status.
- Administrator summary view.

> **Important:** This is an academic demonstration, not a production emergency-dispatch system. It does not contact official emergency services or control traffic signals. Browser geolocation requires user permission and a secure context (localhost is accepted by modern browsers). Route/traffic and facility services depend on external APIs and internet access.

## Technology stack
- Frontend: HTML, CSS, JavaScript, Leaflet
- Backend: Node.js, Express
- Real-time communication: Socket.IO
- Database: MySQL
- Mapping: OpenStreetMap tiles and Leaflet
- Routing/traffic integration: TomTom API
- Nearby facilities: Overpass-based lookup (see `public/import-hospitals.js` and `import-facilities.js`)

## Repository layout
```text
.
├── public/
│   ├── index.html
│   ├── styles.css
│   ├── app.js
│   └── import-hospitals.js
├── sql/
│   └── schema.sql
├── docs/
│   ├── project-overview.md
│   ├── system-architecture.md
│   ├── methodology.md
│   ├── database-design.md
│   └── api-documentation.md
├── tests/
│   └── README.md
├── server.js
├── seed.js
├── import-facilities.js
├── package.json
├── package-lock.json
├── .env.example
└── .gitignore
```

## Requirements
1. Node.js (LTS recommended)
2. MySQL Server and a MySQL client such as MySQL Workbench
3. A TomTom developer API key for routing and traffic tiles
4. Internet access for map tiles and external map services

## Run locally (Windows / VS Code)
1. Extract the repository and open its root folder in VS Code.
2. Start MySQL Server.
3. In MySQL Workbench, open and execute `sql/schema.sql`.
4. Copy `.env.example` to `.env`.
5. Edit `.env` with your local MySQL credentials, a long random session secret, and your TomTom API key.
6. In the VS Code terminal, run:

   ```bash
   npm install
   npm run seed
   npm start
   ```

7. Open `http://localhost:3000` in your browser.

Check `http://localhost:3000/api/health` to verify that the server can reach MySQL.

## Demo accounts
The seed script creates these demonstration accounts:

| Role | Username | Password |
|---|---|---|
| Driver | `driver` | `Driver@123` |
| Traffic police | `police` | `Police@123` |
| Administrator | `admin` | `Admin@123` |

These are public demo credentials. Do not reuse them in a deployed system.

## Suggested demonstration
1. Sign in as the driver and allow location access if you want to test browser geolocation.
2. Select a destination on the map and preview the route.
3. Submit an emergency alert.
4. Open a second browser session and sign in as traffic police.
5. Observe the alert update and change its status.
6. Sign in as administrator to view the summary.

## Configuration and security
- Never commit `.env`, API keys, database passwords, or session secrets.
- `.env.example` contains placeholders only.
- Rotate any credential that has been shared or committed accidentally.
- The default Express in-memory session store is intended for development only.
- Use HTTPS, a persistent session store, stronger account management, rate limiting, audit logging, and security review before any real deployment.

## Known limitations
- External routing, traffic, map-tile, and facility services may be rate-limited, unavailable, or subject to provider terms.
- Geolocation accuracy depends on the browser, device, permissions, and available location services.
- The project is a prototype; it has not been validated for real emergency response.
- Automated test coverage is not included in this repository snapshot.

## Learning path
Start with `public/index.html` and `public/styles.css`, then follow `public/app.js` to understand browser behavior. Next read `server.js` for API and Socket.IO logic, `sql/schema.sql` for the database, and `seed.js` for demo-account creation. The `docs/` directory explains the system at a higher level.
